package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Login button logic
        loginButton.setOnClickListener(v -> {
            // Validate inputs and navigate to database screen
            EditText usernameField = findViewById(R.id.username);
            EditText passwordField = findViewById(R.id.password);

            if (!usernameField.getText().toString().isEmpty() &&
                    !passwordField.getText().toString().isEmpty()) {
                Intent intent = new Intent(MainActivity.this, DatabaseActivity.class);
                startActivity(intent);
            }
        });

        // Create Account button logic (currently redirects to DatabaseActivity)
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DatabaseActivity.class);
            startActivity(intent);
        });
    }
}
